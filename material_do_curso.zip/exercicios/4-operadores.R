# Escreva a resposta logo abaixo da pergunta.
# Ao fazer os exercícios abaixo, escreva a sua 
# interpretação de cada um dos resultados!

# 1. Considere o vetor booleano abaixo:
dolar_subiu <- c(TRUE, TRUE, FALSE, FALSE, TRUE, FALSE, TRUE)

# Este vetor tem informação de uma semana (7 dias) indicando se o dolar subiu (TRUE)
# (ou não subiu - FALSE) no respectivo dia. Interprete os números abaixo:

# (a) length(dolar_subiu)


# (b) dolar_subiu[2]  (ps: a semana começa no domingo)


# (c) sum(dolar_subiu)


# (d) mean(dolar_subiu)


# (e) Agora observe a saída de as.numeric(dolar_subiu). O que o R fez?

