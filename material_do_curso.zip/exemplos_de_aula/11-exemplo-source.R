# Exemplo Source

listar_arquivos <- function(caminho = getwd()){
  list.files(caminho)
}



variavel_exemplo <- 10
